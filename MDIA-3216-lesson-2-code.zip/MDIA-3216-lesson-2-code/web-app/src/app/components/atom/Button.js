export default function Button({ buttonText }){
    return <input type="button" value={buttonText} />

}